import 'package:flutter/material.dart';

class MeditationScreen extends StatelessWidget {
  const MeditationScreen({super.key});

  static const Color accent = Color(0xFF2EE6D6);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: Colors.white, elevation: 0),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const _HeroPicture(),
              const SizedBox(height: 14),
              const Text('Peter Mach',
                  style: TextStyle(fontSize: 12, color: Colors.grey)),
              const SizedBox(height: 6),
              const Text(
                'Mind Deep Relax',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const Text(
                'Join the Community as we prepare over 33 days to relax and '
                'feel joy with the mind and happnies session across the World.',
                style: TextStyle(fontSize: 14, height: 1.45),
              ),
              const SizedBox(height: 22),
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accent,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: const StadiumBorder(),
                  ),
                  onPressed: () {},
                  icon: const Icon(Icons.play_arrow_outlined),
                  label: const Text('Play Next Session',
                      style: TextStyle(fontSize: 16)),
                ),
              ),
              const SizedBox(height: 26),
              const _SessionTile(
                  color: Color(0xFF3A8DFF), title: 'Sweet Memories'),
              const _SessionTile(color: accent, title: 'A Day Dream'),
              const _SessionTile(
                  color: Color(0xFFFF8A1F), title: 'Mind Explore'),
            ],
          ),
        ),
      ),
    );
  }
}

class _HeroPicture extends StatelessWidget {
  const _HeroPicture();

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: Container(
        height: 190,
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFFE14D), Color(0xFFFFC928)],
          ),
        ),
        child: Stack(
          children: [
            const Positioned(
                top: 18,
                left: 30,
                child: Icon(Icons.cloud, color: Colors.white, size: 36)),
            const Positioned(
                top: 30,
                right: 40,
                child: Icon(Icons.cloud, color: Colors.white, size: 28)),
            Positioned(
              right: -30,
              top: 60,
              child: Container(
                width: 170,
                height: 50,
                decoration: const BoxDecoration(
                  color: Color(0xFF4F7194),
                  borderRadius:
                      BorderRadius.vertical(top: Radius.circular(60)),
                ),
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              top: 105,
              child: Container(height: 30, color: const Color(0xFFFFF3B0)),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Center(
                child: Container(
                  width: 120,
                  height: 45,
                  decoration: const BoxDecoration(
                    color: Color(0xFF3E6A7E),
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(6)),
                  ),
                ),
              ),
            ),
            const Positioned(
              bottom: 38,
              left: 0,
              right: 0,
              child: Icon(Icons.accessibility_new,
                  size: 90, color: Color(0xFF1E2A3A)),
            ),
            const Positioned(
                bottom: 8,
                right: 30,
                child: Icon(Icons.grass, size: 48, color: Color(0xFF2F4A5A))),
            const Positioned(
                bottom: 30,
                left: 24,
                child: Icon(Icons.grass, size: 32, color: Color(0xFF2F4A5A))),
          ],
        ),
      ),
    );
  }
}

class _SessionTile extends StatelessWidget {
  const _SessionTile({required this.color, required this.title});

  final Color color;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 22),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.play_arrow_outlined,
                color: Colors.white, size: 22),
          ),
          const SizedBox(width: 14),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w600)),
              const SizedBox(height: 3),
              const Text('December 29 Pre-Launch',
                  style: TextStyle(fontSize: 11, color: Colors.grey)),
            ],
          ),
        ],
      ),
    );
  }
}
