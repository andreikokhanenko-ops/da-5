import 'package:flutter/material.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _Transaction {
  const _Transaction({
    required this.title,
    required this.date,
    required this.amount,
    required this.isOrder,
    required this.icon,
    required this.iconColor,
  });

  final String title;
  final String date;
  final int amount;
  final bool isOrder;
  final IconData icon;
  final Color iconColor;
}

class _WalletScreenState extends State<WalletScreen> {
  static const Color orderColor = Color(0xFFF0445B);
  static const Color topUpColor = Color(0xFF2F80ED);

  int balance = 9379;
  int tabIndex = 3;

  final List<_Transaction> history = [
    const _Transaction(
        title: 'Lawson Chair',
        date: 'Dec 15, 2024 | 10:00 AM',
        amount: 120,
        isOrder: true,
        icon: Icons.chair,
        iconColor: Color(0xFF4DA3FF)),
    const _Transaction(
        title: 'Top Up Wallet',
        date: 'Dec 14, 2024 | 16:42 PM',
        amount: 400,
        isOrder: false,
        icon: Icons.account_balance_wallet,
        iconColor: Colors.white),
    const _Transaction(
        title: 'Parabolic Reflector',
        date: 'Dec 14, 2024 | 11:39 AM',
        amount: 170,
        isOrder: true,
        icon: Icons.light,
        iconColor: Color(0xFFFF8A1F)),
    const _Transaction(
        title: 'Mini Wooden Table',
        date: 'Dec 13, 2024 | 14:46 PM',
        amount: 165,
        isOrder: true,
        icon: Icons.table_restaurant,
        iconColor: Color(0xFFFF7A2E)),
    const _Transaction(
        title: 'Top Up Wallet',
        date: 'Dec 12, 2024 | 09:27 AM',
        amount: 300,
        isOrder: false,
        icon: Icons.account_balance_wallet,
        iconColor: Colors.white),
  ];

  String _money(int value) {
    final s = value.toString();
    final buf = StringBuffer();
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write(',');
      buf.write(s[i]);
    }
    return '\$$buf';
  }

  void _topUp() {
    setState(() {
      balance += 100;
      history.insert(
        0,
        const _Transaction(
          title: 'Top Up Wallet',
          date: 'Just now',
          amount: 100,
          isOrder: false,
          icon: Icons.account_balance_wallet,
          iconColor: Colors.white,
        ),
      );
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Кошелёк пополнен на \$100')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(22, 12, 22, 16),
          children: [
            _header(context),
            const SizedBox(height: 22),
            _card(),
            const SizedBox(height: 24),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Transaction History',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                Text('See All',
                    style: TextStyle(fontWeight: FontWeight.w600)),
              ],
            ),
            const SizedBox(height: 14),
            ...history.map(_transactionTile),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: tabIndex,
        onTap: (i) => setState(() => tabIndex = i),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFF1B2140),
        unselectedItemColor: Colors.black26,
        selectedFontSize: 11,
        unselectedFontSize: 11,
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined), label: 'Home'),
          BottomNavigationBarItem(
              icon: Icon(Icons.shopping_bag_outlined), label: 'Cart'),
          BottomNavigationBarItem(
              icon: Icon(Icons.shopping_cart_outlined), label: 'Orders'),
          BottomNavigationBarItem(
              icon: Icon(Icons.account_balance_wallet), label: 'Wallet'),
          BottomNavigationBarItem(
              icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _header(BuildContext context) {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: const Icon(Icons.segment, size: 28),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Text('My E-Wallet',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600)),
        ),
        const Icon(Icons.search, size: 26),
        const SizedBox(width: 14),
        Container(
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: Colors.black87, width: 1.5),
          ),
          child: const Icon(Icons.more_horiz, size: 18),
        ),
      ],
    );
  }

  Widget _card() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: Container(
        height: 175,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF1B2140), Color(0xFF3A4266)],
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              right: 40,
              top: -30,
              child: Transform.rotate(
                angle: 0.6,
                child: Container(
                    width: 120, height: 120, color: const Color(0x14FFFFFF)),
              ),
            ),
            Positioned(
              left: 120,
              bottom: -50,
              child: Transform.rotate(
                angle: 0.6,
                child: Container(
                    width: 110, height: 110, color: const Color(0x0FFFFFFF)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text('Andrew Ainsley',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.w600)),
                      ),
                      const Text('VISA',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                              fontStyle: FontStyle.italic)),
                      const SizedBox(width: 8),
                      _mastercardLogo(),
                    ],
                  ),
                  const SizedBox(height: 6),
                  const Text('•••• •••• •••• 3629',
                      style: TextStyle(color: Colors.white70, fontSize: 13)),
                  const Spacer(),
                  const Text('Your balance',
                      style: TextStyle(color: Colors.white70, fontSize: 13)),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Expanded(
                        child: Text(
                          _money(balance),
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 34,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      ElevatedButton.icon(
                        onPressed: _topUp,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: Colors.black87,
                          elevation: 0,
                          shape: const StadiumBorder(),
                        ),
                        icon: const Icon(Icons.download, size: 16),
                        label: const Text('Top Up',
                            style: TextStyle(fontWeight: FontWeight.w600)),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _mastercardLogo() {
    return SizedBox(
      width: 34,
      height: 22,
      child: Stack(
        children: [
          Positioned(left: 0, child: _dot(const Color(0xFFE8303F))),
          Positioned(left: 12, child: _dot(const Color(0xCCF7A21B))),
        ],
      ),
    );
  }

  Widget _dot(Color c) => Container(
        width: 22,
        height: 22,
        decoration: BoxDecoration(color: c, shape: BoxShape.circle),
      );

  Widget _transactionTile(_Transaction t) {
    final color = t.isOrder ? orderColor : topUpColor;
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: t.isOrder ? const Color(0xFFF4F5F9) : const Color(0xFF1B2140),
            ),
            child: Icon(t.icon, color: t.iconColor, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(t.title,
                    style: const TextStyle(
                        fontSize: 15, fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                Text(t.date,
                    style:
                        const TextStyle(fontSize: 12, color: Colors.black54)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(_money(t.amount),
                  style: const TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Row(
                children: [
                  Text(t.isOrder ? 'Orders' : 'Top Up',
                      style:
                          const TextStyle(fontSize: 12, color: Colors.black54)),
                  const SizedBox(width: 4),
                  Container(
                    width: 14,
                    height: 14,
                    decoration: BoxDecoration(
                      color: color,
                      borderRadius: BorderRadius.circular(3),
                    ),
                    child: Icon(
                      t.isOrder ? Icons.arrow_upward : Icons.arrow_downward,
                      size: 10,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
