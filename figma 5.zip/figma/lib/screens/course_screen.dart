import 'package:flutter/material.dart';

class CourseScreen extends StatefulWidget {
  const CourseScreen({super.key});

  @override
  State<CourseScreen> createState() => _CourseScreenState();
}

class _Lesson {
  _Lesson(this.title, this.minutes, {this.done = false});
  final String title;
  final int minutes;
  bool done;
}

class _CourseScreenState extends State<CourseScreen> {
  static const Color primary = Color(0xFF5B45F0);
  static const Color primaryLight = Color(0xFF8A6BFF);

  bool enrolled = false;
  bool showAll = false;

  final lessons = <_Lesson>[
    _Lesson('Introduction to 3D', 20, done: true),
    _Lesson('Shapes and Volumes', 35),
    _Lesson('Lights and Materials', 45),
    _Lesson('Rendering the Scene', 50),
  ];

  @override
  Widget build(BuildContext context) {
    final visible = showAll ? lessons : lessons.take(1).toList();

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
          children: [
            Row(
              children: [
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.arrow_back_ios_new,
                      size: 18, color: primary),
                ),
                const SizedBox(width: 4),
                const Text('3D Design Basic',
                    style:
                        TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
              ],
            ),
            const SizedBox(height: 16),
            const _AbstractCover(),
            const SizedBox(height: 16),
            Row(
              children: [
                const Icon(Icons.people_alt_outlined, size: 16, color: primary),
                const SizedBox(width: 4),
                const Text('4,569',
                    style: TextStyle(fontSize: 12, color: Colors.black54)),
                const SizedBox(width: 14),
                const Icon(Icons.star_border, size: 16, color: primary),
                const SizedBox(width: 4),
                const Text('4.9',
                    style: TextStyle(fontSize: 12, color: Colors.black54)),
                const SizedBox(width: 14),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: primary,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Text('Best Seller',
                      style: TextStyle(color: Colors.white, fontSize: 11)),
                ),
              ],
            ),
            const SizedBox(height: 22),
            const Text('3D Design Basic',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            const Text(
              'In this course you will learn how to build a space to a '
              '3-dimensional product. There are 24 premium learning videos for you.',
              style: TextStyle(fontSize: 14, height: 1.5, color: Colors.black87),
            ),
            const SizedBox(height: 22),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('24 Lessons (20 hours)',
                    style: TextStyle(fontSize: 17, color: primary)),
                GestureDetector(
                  onTap: () => setState(() => showAll = !showAll),
                  child: Text(showAll ? 'Hide' : 'See all',
                      style: const TextStyle(
                          color: primary, fontWeight: FontWeight.w500)),
                ),
              ],
            ),
            const SizedBox(height: 14),
            ...visible.map(_lessonTile),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
          child: GestureDetector(
            onTap: () {
              setState(() => enrolled = !enrolled);
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text(enrolled
                    ? 'Вы записались на курс!'
                    : 'Запись на курс отменена'),
              ));
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              height: 54,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                gradient: LinearGradient(
                  colors: enrolled
                      ? const [Color(0xFF2DBE8C), Color(0xFF4AD6A5)]
                      : const [primaryLight, primary],
                ),
              ),
              child: Text(
                enrolled ? 'Enrolled ✓' : 'Enroll - \$24.99',
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w600),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _lessonTile(_Lesson lesson) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFFB04BFF), Color(0xFF4E3BFF)],
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(lesson.title,
                    style: const TextStyle(
                        fontSize: 15, fontWeight: FontWeight.w500)),
                const SizedBox(height: 3),
                Text('${lesson.minutes} mins',
                    style:
                        const TextStyle(fontSize: 11, color: Colors.black45)),
              ],
            ),
          ),
          IconButton(
            onPressed: () => setState(() => lesson.done = !lesson.done),
            icon: Icon(
              lesson.done ? Icons.check_circle : Icons.radio_button_unchecked,
              color: primary,
            ),
          ),
        ],
      ),
    );
  }
}

class _AbstractCover extends StatelessWidget {
  const _AbstractCover();

  Widget _blob(double size, List<Color> colors) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(colors: colors),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Container(
        height: 170,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF2A1BD9), Color(0xFF5B2CF0), Color(0xFF1C1AA8)],
          ),
        ),
        child: Stack(
          children: [
            Positioned(
                left: -30,
                top: -20,
                child: _blob(150,
                    const [Color(0xFF8FE3FF), Color(0x008FE3FF)])),
            Positioned(
                right: -20,
                top: 20,
                child: _blob(160,
                    const [Color(0xFFFF6BD0), Color(0x00FF6BD0)])),
            Positioned(
                left: 90,
                bottom: -60,
                child: _blob(180,
                    const [Color(0xFFB77BFF), Color(0x00B77BFF)])),
          ],
        ),
      ),
    );
  }
}
